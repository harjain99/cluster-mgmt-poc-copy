import pytest
from my_bucket import MyBucketComponent

def test_component_creation():
    component = MyBucketComponent("test")
    assert component.bucket is not None
